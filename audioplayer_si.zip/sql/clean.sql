SET foreign_key_checks = 0;

TRUNCATE TABLE track;
TRUNCATE TABLE album;
TRUNCATE TABLE artist;
TRUNCATE TABLE playlist_track;
TRUNCATE TABLE playlist;
TRUNCATE TABLE playlist_party;
TRUNCATE TABLE remote;

SET foreign_key_checks = 1;
