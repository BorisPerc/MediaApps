<?php

if(!isset($view)) die("Access this page using library.php with the view parameter!");
require_once('global.php');

?>

<?php if(isUpdateAvail()) { ?>
	<li class='option tracklisting'>
		<div class='about'>
			<p>
				<img id='aboutLogo' src='img/piramid.png'>
				<b>A new mp3Player version is available. Nova različica mp3Predvajalnika je na voljo.</b>
				<br>Please update soon to the new version. Prosim nadgradite na novejšo različico programa.</a>
				<!--<br><i>New Version: <?php echo $NVERSION; ?></i>
				<br><i>Current Version: <?php echo $CVERSION; ?></i>-->
			</p>
		</div>
	</li>

	<li class='option tracklisting'>
		<a href='https://github.com/BorisPerc/mp3Player' target='_blank'><img src='img/down.svg'>Download the update package on GitHub - Prenesi paket</a>
	</li>
<?php } else { ?>
	<li class='option tracklisting'>
		<div class='about'>
			<p>
				<b>Your mp3Player installation is up to date. Vaša namestitev mp3Predvajalnika je najnovejša.</b>
			</p>
		</div>
	</li>
<?php } ?>
