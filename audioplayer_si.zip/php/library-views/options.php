<?php

if(!isset($view)) die("Access this page using library.php with the view parameter!");
require_once('global.php');

?>

<li class='option tracklisting'>
	<div class='about'>
		<p>
			<img id='aboutLogo' src='img/piramid.png'>
			<b>Piramide Studio NET</b> Media Portal ❤ PCSNET@2020 HomeCraftSoft@2000 Free WEB Apps / P📋Scripts 🎶 🎧 🔊<br>
			❣ Welcome to Micro Town Lucija City ❣ Portorose, municipality of Piran Slovenia - <a href="./info.html" title="Piramide Studio NET - Audio Server info" target="_self">Audio Server 3P©S-HCS2000™Si-EU</a><br>
			<sup><a href="https://pcsnet.myftp.org" title="Piramide Studio NET - WEB Disk" target="_self">📦 Direct Downloads Enigma 📥</a> - HomeCraftSoft@2000 free WEB Apps
			✨<a href="https://89-212-137-96.static.t-2.net" title="Piramide Studio NET - Analytics / Spletne Analize" target="_self">⚡</a>
			➕<a href="https://perc.ddns.net/wp-login.php" title="Piramide Studio NET - Blog/Forum"  target="_self">👍</a>
			➕<a href="https://obala.hopto.org" title="Piramide Studio NET - Media Server" target="_self">👨‍💻</a>
			➕<a href="https://piramide.zapto.org" title="Piramide Studio NET - Admin Media" target="_self">🎧</a>
			➕<a href="https://oglasi.hopto.org" title="Piramide Studio NET - Oglasna Deska" target="_self">🌍</a>✨</sup> 🥇 🥈 🥉 👨 ‍💻 📦 ⏱️
<!--			<b>Piramide Studio html multimedia server (library and player) <?php echo $CVERSION; ?></b>
			<br>Licensed under the terms of the <a href='#' onclick="ajaxRequest('content','library.php?view=license');">GPLv2</a>
			<br><a href="https://github.com/BorisPerc" target="_blank">Fork me on GitHub</a>
			<br>Piramide Studio &copy; 2020
		</p>
		<p>
			This program uses the <a href='http://getid3.sourceforge.net/' target='blank'>getid3()</a> library v1.9.14
			<br>&copy; 2017 James Heinrich (License: <a href='#' onclick="ajaxRequest('content','library.php?view=license');">GPLv2</a>)
-->
		</p>
	</div>
</li>

<li class='option tracklisting'>
	<a href='#' onclick="ajaxRequest('content','library.php?view=upload');"><img src='img/upload.svg'>Upload and import tracks / Nalaganje in uvoz skladb</a>
</li>
<li class='option tracklisting'>
	<a href='scan.php' target='_blank' onclick='return confirm("This will scan the >music< directory inside your mp3Player directory for new or changed tracks. Depending on the amount of tracks, this could take some time.");'><img src='img/search.svg'>Scan filesystem for tracks / Preglejte datotečni sistem za skladbe</a>
</li>

<li class='option tracklisting'>
	<a href='scan.php?rescan=1' target='_blank' onclick='return confirm("This will truncate your music database and completely rescan the >music< directory inside your mp3Player directory. Depending on the amount of tracks, this could take some time. You should only use this scan method, if you encounter problems with your database.");'><img src='img/search.svg'>Completely rescan filesystem for tracks / Popolnoma znova preglejte datotečni sistem za skladbe</a>
</li>
<li class='option tracklisting'>
	<a href='login.php?changepassword=1'><img src='img/password.svg'>Change password / Spremeni geslo</a>
</li>

<li class='option tracklisting'>
	<a href='login.php?logout=1' onclick=''><img src='img/logout.svg'>Log out / Odjava</a>
</li>
<!--          -->