<?php

if(!isset($view)) die("Access this page using library.php with the view parameter!");
require_once('global.php');

?>

<li class='option tracklisting'>
	<a href='#' onclick="ajaxRequest('content','library.php?view=genre');"><img src='img/track.svg'>Genres / Žanri</a>
</li>
<li class='option tracklisting'>
	<a href='#' onclick="ajaxRequest('content','library.php?view=recentlyadded');"><img src='img/recent.svg'>Recently added tracks / Nedavno dodane skladbe</a>
</li>
<li class='option tracklisting'>
	<a href='#' onclick="ajaxRequest('content','library.php?view=stats');"><img src='img/menu.svg'>Statistics / Statistika javnih datotek</a>
</li>
<li class='option tracklisting'>
	<a href='https://obala.hopto.org' onclick="ajaxRequest('content','https://obala.hopto.org');"><img src='img/menu.svg'>PCSNET Media Server / Medijski Strežnik</a>
</li>
<li class='option tracklisting'>
	<a href='https://perc.ddns.net' onclick="ajaxRequest('content','https://perc.ddns.net');"><img src='img/menu.svg'>PCSNET Blog / Forum</a>
</li>