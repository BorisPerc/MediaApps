<?php
header('location: https://obala.hopto.org');
die();
?>
